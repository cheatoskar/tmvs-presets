Example entry of the TM Horizon launcher: this pack contains no textures, so it changes nothing in the game.
